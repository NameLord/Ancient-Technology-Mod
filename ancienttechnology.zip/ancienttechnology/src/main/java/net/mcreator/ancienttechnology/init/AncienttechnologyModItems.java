
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ancienttechnology.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.ancienttechnology.item.TitanMailIngotItem;
import net.mcreator.ancienttechnology.item.QuantumStarItem;
import net.mcreator.ancienttechnology.item.QuantumInfuserItem;
import net.mcreator.ancienttechnology.item.HanordixIngotItem;
import net.mcreator.ancienttechnology.AncienttechnologyMod;

public class AncienttechnologyModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AncienttechnologyMod.MODID);
	public static final RegistryObject<Item> HANORDIX_INGOT = REGISTRY.register("hanordix_ingot", () -> new HanordixIngotItem());
	public static final RegistryObject<Item> QUANTUM_STAR = REGISTRY.register("quantum_star", () -> new QuantumStarItem());
	public static final RegistryObject<Item> TITAN_MAIL_INGOT = REGISTRY.register("titan_mail_ingot", () -> new TitanMailIngotItem());
	public static final RegistryObject<Item> QUANTUM_INFUSER = REGISTRY.register("quantum_infuser", () -> new QuantumInfuserItem());
}
